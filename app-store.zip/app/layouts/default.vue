<template>
    <slot />
</template>

